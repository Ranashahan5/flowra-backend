require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const { startScheduler } = require('./scheduler');
const { helmetMiddleware, authLimiter, apiLimiter } = require('./middleware/security');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Security headers (helmet) ─────────────────────────
app.use(helmetMiddleware);

// ─── CORS — only allow your frontend domain ────────────
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  methods: ['GET', 'POST', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}));

// ─── Body parser (limit size to prevent DOS) ───────────
app.use(express.json({ limit: '100kb' }));

// ─── Rate limiting ─────────────────────────────────────
app.use('/api/auth', authLimiter);   // Strict: 10 req / 15 min
app.use('/api',      apiLimiter);    // General: 100 req / min

// ─── Routes ───────────────────────────────────────────
// Webhook must come BEFORE express.json() to get raw body
app.use('/api/billing/webhook', express.raw({ type: 'application/json' }));

app.use('/api/auth',        require('./routes/auth'));
app.use('/api/automations', require('./routes/automations'));
app.use('/api/logs',        require('./routes/logs'));
app.use('/api/billing',     require('./routes/billing')); // Stripe — add keys when ready

// ─── Health Check ─────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '1.0.0',
    uptime: Math.floor(process.uptime()) + 's',
  });
});

// ─── 404 Handler ──────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
});

// ─── Error Handler ────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[Error]', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

// ─── Start Server ─────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 Flowra API running on http://localhost:${PORT}`);
  console.log(`📋 Routes:`);
  console.log(`   POST   /api/auth/register`);
  console.log(`   POST   /api/auth/login`);
  console.log(`   GET    /api/auth/me`);
  console.log(`   GET    /api/automations`);
  console.log(`   POST   /api/automations`);
  console.log(`   PATCH  /api/automations/:id`);
  console.log(`   DELETE /api/automations/:id`);
  console.log(`   POST   /api/automations/:id/run`);
  console.log(`   GET    /api/logs`);
  console.log(`   GET    /api/logs/stats`);
  console.log(`\n⏰ Starting scheduler...`);
  startScheduler();
});
