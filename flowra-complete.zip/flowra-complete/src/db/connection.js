const { Pool } = require('pg');
require('dotenv').config();

// Create a connection pool (reuses connections = faster)
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false,
  max: 10,          // max 10 connections in pool
  idleTimeoutMillis: 30000,
});

// Test connection on startup
pool.connect((err, client, release) => {
  if (err) {
    console.error('❌ Database connection failed:', err.message);
  } else {
    console.log('✅ Database connected');
    release();
  }
});

// Helper: run a query with automatic error handling
const query = async (text, params) => {
  const start = Date.now();
  const result = await pool.query(text, params);
  const duration = Date.now() - start;

  if (process.env.NODE_ENV === 'development') {
    console.log(`[DB] ${duration}ms → ${text.substring(0, 60)}...`);
  }

  return result;
};

module.exports = { query, pool };
