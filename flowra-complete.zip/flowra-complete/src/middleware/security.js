// src/middleware/security.js
// All security protections in one file

const rateLimit = require('express-rate-limit');
const helmet    = require('helmet');
const validator = require('validator');

// ─── Helmet (sets secure HTTP headers) ───────────────────────
// Protects against XSS, clickjacking, sniffing attacks
const helmetMiddleware = helmet({
  contentSecurityPolicy: false, // Disable if you serve a frontend from same origin
});

// ─── Rate Limiters ────────────────────────────────────────────

// Auth routes: max 10 attempts per 15 min (stops brute force)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  message: { error: 'Too many login attempts. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// API routes: max 100 requests per minute per user
const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100,
  message: { error: 'Too many requests. Please slow down.' },
  keyGenerator: (req) => req.user?.id || req.ip, // Rate limit per user, not just IP
  standardHeaders: true,
  legacyHeaders: false,
});

// Run endpoint: max 10 runs per minute (prevents abuse of Puppeteer)
const runLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: 'Too many automation runs. Please wait a minute.' },
  keyGenerator: (req) => req.user?.id || req.ip,
});

// ─── Input Sanitizer ─────────────────────────────────────────
// Cleans and validates automation steps before they reach Puppeteer

const ALLOWED_STEP_TYPES = [
  'click', 'type', 'fill', 'select', 'navigate',
  'waitForElement', 'wait', 'keyPress', 'scroll', 'screenshot'
];

const ALLOWED_KEYS = [
  'Enter', 'Tab', 'Escape', 'Backspace', 'Delete',
  'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'
];

function sanitizeSteps(steps) {
  if (!Array.isArray(steps)) throw new Error('Steps must be an array');
  if (steps.length > 200) throw new Error('Too many steps (max 200)');

  return steps.map((step, i) => {
    if (!step || typeof step !== 'object') {
      throw new Error(`Step ${i} is invalid`);
    }

    // Only allow known step types
    if (!ALLOWED_STEP_TYPES.includes(step.type)) {
      throw new Error(`Unknown step type: "${step.type}"`);
    }

    const clean = { type: step.type };

    // Sanitize selector (CSS selector used by Puppeteer)
    if (step.selector !== undefined) {
      if (typeof step.selector !== 'string') throw new Error(`Step ${i}: selector must be a string`);
      if (step.selector.length > 500) throw new Error(`Step ${i}: selector too long`);
      // Block script injection attempts in selectors
      if (/<script|javascript:|on\w+=/i.test(step.selector)) {
        throw new Error(`Step ${i}: invalid selector`);
      }
      clean.selector = step.selector.trim();
    }

    // Sanitize value (text to type into inputs)
    if (step.value !== undefined) {
      clean.value = String(step.value).substring(0, 5000); // Max 5000 chars
    }

    // Sanitize URL (only allow http/https)
    if (step.url !== undefined) {
      if (!validator.isURL(step.url, { protocols: ['http', 'https'], require_protocol: true })) {
        throw new Error(`Step ${i}: invalid URL "${step.url}"`);
      }
      clean.url = step.url;
    }

    // Sanitize key press (only allow known safe keys)
    if (step.key !== undefined) {
      if (!ALLOWED_KEYS.includes(step.key)) {
        throw new Error(`Step ${i}: key "${step.key}" not allowed`);
      }
      clean.key = step.key;
    }

    return clean;
  });
}

// ─── URL Validator ────────────────────────────────────────────
function validateStartUrl(url) {
  if (!url || typeof url !== 'string') throw new Error('start_url is required');
  if (!validator.isURL(url, { protocols: ['http', 'https'], require_protocol: true })) {
    throw new Error('start_url must be a valid http/https URL');
  }
  // Block localhost / internal IPs (SSRF protection)
  if (/localhost|127\.|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\./i.test(url)) {
    throw new Error('start_url cannot point to internal addresses');
  }
  return url.trim();
}

// ─── Email Validator ──────────────────────────────────────────
function validateEmail(email) {
  if (!email || !validator.isEmail(email)) {
    throw new Error('Invalid email address');
  }
  return validator.normalizeEmail(email);
}

module.exports = {
  helmetMiddleware,
  authLimiter,
  apiLimiter,
  runLimiter,
  sanitizeSteps,
  validateStartUrl,
  validateEmail,
};
