const express = require('express');
const { query } = require('../db/connection');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.use(authenticate);

// GET /api/logs — all logs for the user
router.get('/', async (req, res) => {
  const { limit = 50, offset = 0, automation_id } = req.query;

  try {
    let sql = `
      SELECT l.*, a.name as automation_name
      FROM execution_logs l
      JOIN automations a ON l.automation_id = a.id
      WHERE l.user_id = $1
    `;
    const params = [req.user.id];

    if (automation_id) {
      sql += ` AND l.automation_id = $${params.length + 1}`;
      params.push(automation_id);
    }

    sql += ` ORDER BY l.started_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch logs' });
  }
});

// GET /api/logs/stats — dashboard stats (runs today, success rate, etc.)
router.get('/stats', async (req, res) => {
  try {
    const statsResult = await query(
      `SELECT
        COUNT(*) FILTER (WHERE started_at > NOW() - INTERVAL '24 hours') as runs_today,
        COUNT(*) FILTER (WHERE status = 'success') as total_success,
        COUNT(*) FILTER (WHERE status = 'failed') as total_failed,
        AVG(duration_ms) FILTER (WHERE status = 'success') as avg_duration_ms
       FROM execution_logs WHERE user_id = $1`,
      [req.user.id]
    );

    res.json(statsResult.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch stats' });
  }
});

// GET /api/logs/:id — single log detail
router.get('/:id', async (req, res) => {
  try {
    const result = await query(
      `SELECT l.*, a.name as automation_name, a.steps
       FROM execution_logs l
       JOIN automations a ON l.automation_id = a.id
       WHERE l.id = $1 AND l.user_id = $2`,
      [req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Log not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch log' });
  }
});

module.exports = router;
