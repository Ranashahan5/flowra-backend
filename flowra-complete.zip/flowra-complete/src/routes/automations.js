const express = require('express');
const { query } = require('../db/connection');
const { authenticate } = require('../middleware/auth');
const { runAutomation } = require('../automation/player');
const { sanitizeSteps, validateStartUrl, runLimiter } = require('../middleware/security');

const router = express.Router();

// All routes below require authentication
router.use(authenticate);

// GET /api/automations — list all user's automations
router.get('/', async (req, res) => {
  try {
    const result = await query(
      `SELECT id, name, description, start_url, trigger_type, trigger_config,
              is_active, last_run_at, created_at,
              jsonb_array_length(steps) as step_count
       FROM automations WHERE user_id = $1
       ORDER BY created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch automations' });
  }
});

// GET /api/automations/:id — get one automation
router.get('/:id', async (req, res) => {
  try {
    const result = await query(
      'SELECT * FROM automations WHERE id = $1 AND user_id = $2',
      [req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Automation not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch automation' });
  }
});

// POST /api/automations — create new automation
router.post('/', async (req, res) => {
  const { name, description, start_url, steps, trigger_type, trigger_config } = req.body;

  if (!name || !start_url || !steps) {
    return res.status(400).json({ error: 'name, start_url, and steps are required' });
  }

  // Validate & sanitize inputs
  try {
    validateStartUrl(start_url);
    sanitizeSteps(steps);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  // Sanitize name
  if (typeof name !== 'string' || name.length > 100) {
    return res.status(400).json({ error: 'Name must be under 100 characters' });
  }

  // Check plan limits
  const limitCheck = await checkPlanLimits(req.user.id, req.user.plan);
  if (!limitCheck.allowed) {
    return res.status(403).json({ error: limitCheck.reason });
  }

  try {
    const result = await query(
      `INSERT INTO automations
        (user_id, name, description, start_url, steps, trigger_type, trigger_config)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        req.user.id,
        name,
        description || '',
        start_url,
        JSON.stringify(steps),
        trigger_type || 'manual',
        JSON.stringify(trigger_config || {})
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create automation' });
  }
});

// PATCH /api/automations/:id — update automation
router.patch('/:id', async (req, res) => {
  const { name, description, start_url, steps, trigger_type, trigger_config, is_active } = req.body;

  try {
    const result = await query(
      `UPDATE automations
       SET name = COALESCE($1, name),
           description = COALESCE($2, description),
           start_url = COALESCE($3, start_url),
           steps = COALESCE($4, steps),
           trigger_type = COALESCE($5, trigger_type),
           trigger_config = COALESCE($6, trigger_config),
           is_active = COALESCE($7, is_active),
           updated_at = NOW()
       WHERE id = $8 AND user_id = $9
       RETURNING *`,
      [
        name, description, start_url,
        steps ? JSON.stringify(steps) : null,
        trigger_type,
        trigger_config ? JSON.stringify(trigger_config) : null,
        is_active,
        req.params.id,
        req.user.id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Automation not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Could not update automation' });
  }
});

// DELETE /api/automations/:id
router.delete('/:id', async (req, res) => {
  try {
    const result = await query(
      'DELETE FROM automations WHERE id = $1 AND user_id = $2 RETURNING id',
      [req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Automation not found' });
    }

    res.json({ message: 'Deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Could not delete automation' });
  }
});

// POST /api/automations/:id/run — manually trigger an automation
router.post('/:id/run', runLimiter, async (req, res) => {
  try {
    const result = await query(
      'SELECT * FROM automations WHERE id = $1 AND user_id = $2',
      [req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Automation not found' });
    }

    const automation = result.rows[0];

    // Start automation in background (don't wait for it)
    runAutomation(automation).catch(console.error);

    res.json({ message: 'Automation started', automationId: automation.id });
  } catch (err) {
    res.status(500).json({ error: 'Could not start automation' });
  }
});

// Helper: check if user is within plan limits
async function checkPlanLimits(userId, plan) {
  const countResult = await query(
    'SELECT COUNT(*) FROM automations WHERE user_id = $1',
    [userId]
  );
  const limitResult = await query(
    'SELECT max_automations FROM plan_limits WHERE plan = $1',
    [plan]
  );

  const currentCount = parseInt(countResult.rows[0].count);
  const maxAllowed = limitResult.rows[0]?.max_automations ?? 3;

  if (maxAllowed !== -1 && currentCount >= maxAllowed) {
    return { allowed: false, reason: `Plan limit reached (${maxAllowed} automations). Upgrade to add more.` };
  }

  return { allowed: true };
}

module.exports = router;
