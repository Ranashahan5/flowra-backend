// src/routes/billing.js
// Stripe billing — plug in whenever you're ready
// All sensitive logic server-side only, never expose Stripe secret key to frontend

const express = require('express');
const { query } = require('../db/connection');
const { authenticate } = require('../middleware/auth');
const { authLimiter } = require('../middleware/security');

const router = express.Router();

// ─── Lazy-load Stripe (only if keys are set) ─────────────────
// This means the app runs fine WITHOUT Stripe configured
function getStripe() {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error('Stripe is not configured yet');
  }
  const Stripe = require('stripe');
  return Stripe(process.env.STRIPE_SECRET_KEY);
}

// ─── Price IDs (set these in .env after creating products in Stripe dashboard)
const PLANS = {
  starter: {
    name: 'Starter',
    priceId: process.env.STRIPE_STARTER_PRICE_ID, // e.g. price_xxx
    maxAutomations: 10,
    maxRunsPerDay: 10,
  },
  pro: {
    name: 'Pro',
    priceId: process.env.STRIPE_PRO_PRICE_ID,
    maxAutomations: -1,  // unlimited
    maxRunsPerDay: -1,
  },
};

// ─── Check if billing is enabled ─────────────────────────────
router.get('/status', (req, res) => {
  res.json({
    enabled: !!process.env.STRIPE_SECRET_KEY,
    plans: Object.entries(PLANS).map(([key, plan]) => ({
      id: key,
      name: plan.name,
      // Never expose priceId to frontend
    })),
  });
});

// ─── Create checkout session ──────────────────────────────────
// Frontend calls this → we create a Stripe session → redirect user to Stripe
router.post('/create-checkout', authenticate, authLimiter, async (req, res) => {
  const { plan } = req.body;

  // Validate plan exists
  if (!PLANS[plan]) {
    return res.status(400).json({ error: 'Invalid plan' });
  }

  if (!PLANS[plan].priceId) {
    return res.status(503).json({ error: 'Billing not configured yet' });
  }

  try {
    const stripe = getStripe();

    // Get or create Stripe customer for this user
    const stripeCustomerId = await getOrCreateCustomer(stripe, req.user.id, req.user.email);

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: stripeCustomerId,
      payment_method_types: ['card'],
      line_items: [{
        price: PLANS[plan].priceId,
        quantity: 1,
      }],
      mode: 'subscription',
      success_url: `${process.env.FRONTEND_URL}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/billing/cancelled`,
      metadata: {
        userId: req.user.id,  // So webhook knows which user upgraded
        plan,
      },
      subscription_data: {
        metadata: { userId: req.user.id, plan },
      },
    });

    // Return ONLY the session URL — never the secret key
    res.json({ url: session.url });

  } catch (err) {
    console.error('[Billing] Checkout error:', err.message);
    res.status(500).json({ error: 'Could not create checkout session' });
  }
});

// ─── Customer portal (manage/cancel subscription) ─────────────
router.post('/portal', authenticate, async (req, res) => {
  try {
    const stripe = getStripe();

    const result = await query(
      'SELECT stripe_customer_id FROM users WHERE id = $1',
      [req.user.id]
    );

    const customerId = result.rows[0]?.stripe_customer_id;
    if (!customerId) {
      return res.status(404).json({ error: 'No subscription found' });
    }

    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${process.env.FRONTEND_URL}/dashboard`,
    });

    res.json({ url: session.url });

  } catch (err) {
    console.error('[Billing] Portal error:', err.message);
    res.status(500).json({ error: 'Could not open billing portal' });
  }
});

// ─── Get current subscription info ───────────────────────────
router.get('/subscription', authenticate, async (req, res) => {
  try {
    const result = await query(
      'SELECT plan, stripe_customer_id, subscription_status FROM users WHERE id = $1',
      [req.user.id]
    );

    const user = result.rows[0];
    res.json({
      plan: user.plan,
      status: user.subscription_status || 'active',
      isSubscribed: user.plan !== 'free',
    });

  } catch (err) {
    res.status(500).json({ error: 'Could not fetch subscription' });
  }
});

// ─── Stripe Webhook (MOST IMPORTANT — handles payment events) ─
// Stripe calls this endpoint after every payment event
// This is how we know when someone paid, cancelled, or failed
router.post(
  '/webhook',
  express.raw({ type: 'application/json' }), // Raw body required for signature check
  async (req, res) => {
    const sig = req.headers['stripe-signature'];

    if (!process.env.STRIPE_WEBHOOK_SECRET) {
      return res.status(503).json({ error: 'Webhook not configured' });
    }

    let event;

    // ⚠️ CRITICAL: Verify webhook signature
    // This prevents anyone from faking a payment event
    try {
      const stripe = getStripe();
      event = stripe.webhooks.constructEvent(
        req.body,                            // Raw body
        sig,                                 // Stripe signature header
        process.env.STRIPE_WEBHOOK_SECRET    // Webhook secret from Stripe dashboard
      );
    } catch (err) {
      console.error('[Webhook] Signature verification failed:', err.message);
      return res.status(400).json({ error: 'Invalid webhook signature' });
    }

    // Handle different payment events
    try {
      switch (event.type) {

        // ✅ Payment succeeded → upgrade user plan
        case 'checkout.session.completed': {
          const session = event.data.object;
          const userId  = session.metadata?.userId;
          const plan    = session.metadata?.plan;

          if (userId && plan && PLANS[plan]) {
            await query(
              `UPDATE users
               SET plan = $1,
                   stripe_customer_id = $2,
                   subscription_status = 'active'
               WHERE id = $3`,
              [plan, session.customer, userId]
            );

            // Update plan limits in DB
            await query(
              `UPDATE plan_limits SET
                max_automations = $1,
                max_runs_per_day = $2
               WHERE plan = $3`,
              [PLANS[plan].maxAutomations, PLANS[plan].maxRunsPerDay, plan]
            );

            console.log(`[Webhook] ✅ User ${userId} upgraded to ${plan}`);
          }
          break;
        }

        // ✅ Subscription renewed successfully
        case 'invoice.paid': {
          const invoice = event.data.object;
          await query(
            `UPDATE users SET subscription_status = 'active'
             WHERE stripe_customer_id = $1`,
            [invoice.customer]
          );
          break;
        }

        // ❌ Payment failed → downgrade to free
        case 'invoice.payment_failed': {
          const invoice = event.data.object;
          await query(
            `UPDATE users SET subscription_status = 'past_due'
             WHERE stripe_customer_id = $1`,
            [invoice.customer]
          );
          console.log(`[Webhook] ⚠️ Payment failed for customer ${invoice.customer}`);
          break;
        }

        // ❌ Subscription cancelled → downgrade to free
        case 'customer.subscription.deleted': {
          const subscription = event.data.object;
          await query(
            `UPDATE users SET plan = 'free', subscription_status = 'cancelled'
             WHERE stripe_customer_id = $1`,
            [subscription.customer]
          );
          console.log(`[Webhook] ❌ Subscription cancelled for ${subscription.customer}`);
          break;
        }

        default:
          // Ignore other events
          break;
      }

      res.json({ received: true });

    } catch (err) {
      console.error('[Webhook] Handler error:', err.message);
      res.status(500).json({ error: 'Webhook handler failed' });
    }
  }
);

// ─── Helper: get or create Stripe customer ────────────────────
async function getOrCreateCustomer(stripe, userId, email) {
  // Check if we already have a Stripe customer ID
  const result = await query(
    'SELECT stripe_customer_id FROM users WHERE id = $1',
    [userId]
  );

  const existingId = result.rows[0]?.stripe_customer_id;
  if (existingId) return existingId;

  // Create new Stripe customer
  const customer = await stripe.customers.create({
    email,
    metadata: { userId },
  });

  // Save to DB
  await query(
    'UPDATE users SET stripe_customer_id = $1 WHERE id = $2',
    [customer.id, userId]
  );

  return customer.id;
}

module.exports = router;
