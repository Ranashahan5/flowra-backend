const cron = require('node-cron');
const { query } = require('../db/connection');
const { runAutomation } = require('../automation/player');

// Main scheduler: checks every minute for automations that should run
function startScheduler() {
  console.log('[Scheduler] ⏰ Started — checking every minute');

  cron.schedule('* * * * *', async () => {
    try {
      await checkAndRunScheduledTasks();
    } catch (err) {
      console.error('[Scheduler] Error:', err.message);
    }
  });
}

async function checkAndRunScheduledTasks() {
  // Get all active, scheduled automations
  const result = await query(
    `SELECT * FROM automations
     WHERE is_active = true
     AND trigger_type = 'schedule'`,
    []
  );

  const now = new Date();

  for (const automation of result.rows) {
    const config = automation.trigger_config;

    if (!config?.cron) continue;

    // Check if this automation's cron expression matches current time
    if (cron.validate(config.cron) && shouldRunNow(config.cron, now)) {

      // Check if already ran recently (within the last 50 seconds) to prevent duplicates
      if (automation.last_run_at) {
        const lastRun = new Date(automation.last_run_at);
        const secondsSinceLastRun = (now - lastRun) / 1000;
        if (secondsSinceLastRun < 50) {
          continue; // Skip: already ran this minute
        }
      }

      console.log(`[Scheduler] 🚀 Triggering: "${automation.name}" (cron: ${config.cron})`);
      runAutomation(automation).catch(err => {
        console.error(`[Scheduler] Failed to run "${automation.name}":`, err.message);
      });
    }
  }
}

/**
 * Check if a cron expression should fire at the given time
 * Uses node-cron's internal matching logic
 */
function shouldRunNow(cronExpression, now) {
  // Normalize to minute boundary
  const minute = now.getMinutes();
  const hour = now.getHours();
  const dayOfMonth = now.getDate();
  const month = now.getMonth() + 1;
  const dayOfWeek = now.getDay();

  const parts = cronExpression.trim().split(' ');
  if (parts.length !== 5) return false;

  const [cronMin, cronHour, cronDom, cronMonth, cronDow] = parts;

  return (
    matchesCronField(cronMin, minute) &&
    matchesCronField(cronHour, hour) &&
    matchesCronField(cronDom, dayOfMonth) &&
    matchesCronField(cronMonth, month) &&
    matchesCronField(cronDow, dayOfWeek)
  );
}

function matchesCronField(field, value) {
  if (field === '*') return true;

  // Handle step values like */5
  if (field.startsWith('*/')) {
    const step = parseInt(field.slice(2));
    return value % step === 0;
  }

  // Handle ranges like 9-17
  if (field.includes('-')) {
    const [min, max] = field.split('-').map(Number);
    return value >= min && value <= max;
  }

  // Handle comma-separated like 1,3,5
  if (field.includes(',')) {
    return field.split(',').map(Number).includes(value);
  }

  return parseInt(field) === value;
}

module.exports = { startScheduler };
