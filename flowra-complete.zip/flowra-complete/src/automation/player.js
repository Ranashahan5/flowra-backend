const puppeteer = require('puppeteer');
const { query } = require('../db/connection');

// Map of currently running automations (prevent duplicate runs)
const runningTasks = new Map();

/**
 * Run an automation using Puppeteer
 * @param {Object} automation - Full automation row from DB
 */
async function runAutomation(automation) {
  const automationId = automation.id;

  // Prevent duplicate concurrent runs
  if (runningTasks.has(automationId)) {
    console.log(`[Player] Automation ${automationId} is already running`);
    return;
  }

  // Create an execution log entry
  const logResult = await query(
    `INSERT INTO execution_logs
      (automation_id, user_id, status, steps_total)
     VALUES ($1, $2, 'running', $3)
     RETURNING id`,
    [automationId, automation.user_id, automation.steps.length]
  );

  const logId = logResult.rows[0].id;
  const startTime = Date.now();
  runningTasks.set(automationId, logId);

  let browser = null;

  try {
    // Launch headless browser
    browser = await puppeteer.launch({
      headless: process.env.PUPPETEER_HEADLESS !== 'false',
      args: [
        '--no-sandbox',               // Required for Render/Railway
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',    // Prevents memory issues on Linux
      ]
    });

    const page = await browser.newPage();

    // Set realistic viewport & user agent
    await page.setViewport({ width: 1280, height: 720 });
    await page.setUserAgent(
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36'
    );

    // Navigate to starting URL
    console.log(`[Player] Starting automation ${automation.name} → ${automation.start_url}`);
    await page.goto(automation.start_url, { waitUntil: 'networkidle2', timeout: 30000 });

    // Execute each recorded step
    const steps = automation.steps;
    let stepsCompleted = 0;

    for (const step of steps) {
      await executeStep(page, step);
      stepsCompleted++;

      // Update progress in DB every 5 steps
      if (stepsCompleted % 5 === 0) {
        await query(
          'UPDATE execution_logs SET steps_completed = $1 WHERE id = $2',
          [stepsCompleted, logId]
        );
      }

      // Small delay between steps (more human-like, avoids detection)
      await sleep(300 + Math.random() * 400);
    }

    // Success! Update log
    const duration = Date.now() - startTime;
    await query(
      `UPDATE execution_logs
       SET status = 'success', finished_at = NOW(), duration_ms = $1, steps_completed = $2
       WHERE id = $3`,
      [duration, stepsCompleted, logId]
    );

    // Update automation's last_run_at
    await query(
      'UPDATE automations SET last_run_at = NOW() WHERE id = $1',
      [automationId]
    );

    console.log(`[Player] ✅ Automation "${automation.name}" completed in ${duration}ms`);

  } catch (err) {
    // Failure: log the error
    console.error(`[Player] ❌ Automation "${automation.name}" failed:`, err.message);

    await query(
      `UPDATE execution_logs
       SET status = 'failed', finished_at = NOW(),
           duration_ms = $1, error_message = $2
       WHERE id = $3`,
      [Date.now() - startTime, err.message, logId]
    );

  } finally {
    if (browser) await browser.close();
    runningTasks.delete(automationId);
  }
}

/**
 * Execute a single recorded step on a Puppeteer page
 * Steps are recorded by the Chrome extension and stored in this format
 */
async function executeStep(page, step) {
  const { type, selector, value, url, key } = step;

  switch (type) {
    // Click an element
    case 'click':
      await page.waitForSelector(selector, { timeout: 10000 });
      await page.click(selector);
      break;

    // Type text into an input
    case 'type':
      await page.waitForSelector(selector, { timeout: 10000 });
      await page.click(selector);
      await page.keyboard.type(value, { delay: 50 }); // Human-like typing
      break;

    // Clear an input then type
    case 'fill':
      await page.waitForSelector(selector, { timeout: 10000 });
      await page.click(selector, { clickCount: 3 }); // Select all text
      await page.keyboard.type(value, { delay: 50 });
      break;

    // Select a dropdown option
    case 'select':
      await page.waitForSelector(selector, { timeout: 10000 });
      await page.select(selector, value);
      break;

    // Navigate to a URL
    case 'navigate':
      await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
      break;

    // Wait for an element to appear
    case 'waitForElement':
      await page.waitForSelector(selector, { timeout: 15000 });
      break;

    // Wait a fixed number of milliseconds
    case 'wait':
      await sleep(parseInt(value) || 1000);
      break;

    // Press a keyboard key (Enter, Tab, Escape, etc.)
    case 'keyPress':
      await page.keyboard.press(key || 'Enter');
      break;

    // Take a screenshot (for debugging or proof)
    case 'screenshot':
      await page.screenshot({ path: `/tmp/screenshot_${Date.now()}.png` });
      break;

    // Scroll to a position or element
    case 'scroll':
      if (selector) {
        await page.evaluate((sel) => {
          document.querySelector(sel)?.scrollIntoView({ behavior: 'smooth' });
        }, selector);
      } else {
        await page.evaluate((y) => window.scrollTo(0, y), value || 500);
      }
      break;

    default:
      console.warn(`[Player] Unknown step type: ${type}`);
  }
}

// Utility sleep function
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = { runAutomation };
