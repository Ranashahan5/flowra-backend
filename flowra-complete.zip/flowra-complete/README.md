# Flowra Backend

Browser automation API built with Express, PostgreSQL, and Puppeteer.

---

## Stack
- **Express.js** — API server
- **PostgreSQL** — Database (Supabase recommended)
- **Puppeteer** — Headless browser automation engine
- **node-cron** — Scheduled task runner
- **JWT** — Authentication

---

## Setup (Local)

### 1. Install dependencies
```bash
npm install
```

### 2. Set up database
- Create a free Supabase project at https://supabase.com
- Go to SQL Editor → paste contents of `src/db/schema.sql` → Run

### 3. Configure environment
```bash
cp .env.example .env
# Edit .env with your database URL and a secret key
```

### 4. Start development server
```bash
npm run dev
# Server starts at http://localhost:3000
```

---

## API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Get JWT token |
| GET | `/api/auth/me` | Get current user |

### Automations
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/automations` | List all automations |
| POST | `/api/automations` | Create automation |
| PATCH | `/api/automations/:id` | Update automation |
| DELETE | `/api/automations/:id` | Delete automation |
| POST | `/api/automations/:id/run` | Run now |

### Logs
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/logs` | List execution logs |
| GET | `/api/logs/stats` | Dashboard stats |
| GET | `/api/logs/:id` | Single log detail |

---

## Step Format (from Chrome Extension)

The `steps` field in an automation is a JSON array of actions:

```json
[
  { "type": "navigate", "url": "https://example.com" },
  { "type": "click", "selector": "#login-button" },
  { "type": "fill", "selector": "#email", "value": "user@email.com" },
  { "type": "fill", "selector": "#password", "value": "mypassword" },
  { "type": "keyPress", "key": "Enter" },
  { "type": "wait", "value": "2000" },
  { "type": "screenshot" }
]
```

**Supported step types:**
- `navigate` — Go to a URL
- `click` — Click an element
- `type` — Type text (appends to existing)
- `fill` — Clear then type text
- `select` — Choose a dropdown option
- `keyPress` — Press a key (Enter, Tab, Escape...)
- `waitForElement` — Wait until element appears
- `wait` — Wait X milliseconds
- `scroll` — Scroll to element or position
- `screenshot` — Take a screenshot

---

## Schedule Format (cron)

When `trigger_type = 'schedule'`, set `trigger_config.cron`:

```json
{ "cron": "0 9 * * 1-5" }  // Every weekday at 9am
{ "cron": "*/30 * * * *" }  // Every 30 minutes
{ "cron": "0 8 * * *" }     // Every day at 8am
```

---

## Deploy to Render.com

1. Push to GitHub
2. New Web Service → Connect repo
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables from `.env`
6. Deploy!

Note: Puppeteer needs these env vars on Render:
```
PUPPETEER_HEADLESS=true
```
