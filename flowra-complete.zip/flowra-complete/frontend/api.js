// api.js — All Flowra API calls in one place
// Drop this file into your src/ folder

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

// ─── Core fetch helper ─────────────────────────────────────────
// Automatically adds JWT token + handles errors
async function request(endpoint, options = {}) {
  const token = localStorage.getItem('flowra_token');

  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  };

  const response = await fetch(`${BASE_URL}${endpoint}`, config);
  const data = await response.json();

  // If token expired, log user out
  if (response.status === 401) {
    localStorage.removeItem('flowra_token');
    localStorage.removeItem('flowra_user');
    window.location.href = '/login';
    return;
  }

  if (!response.ok) {
    throw new Error(data.error || `Request failed: ${response.status}`);
  }

  return data;
}

// ─── Auth ──────────────────────────────────────────────────────
export const auth = {
  register: (email, password) =>
    request('/auth/register', { method: 'POST', body: { email, password } }),

  login: (email, password) =>
    request('/auth/login', { method: 'POST', body: { email, password } }),

  me: () => request('/auth/me'),

  // Save token + user to localStorage after login/register
  saveSession: ({ token, user }) => {
    localStorage.setItem('flowra_token', token);
    localStorage.setItem('flowra_user', JSON.stringify(user));
  },

  // Clear session (logout)
  logout: () => {
    localStorage.removeItem('flowra_token');
    localStorage.removeItem('flowra_user');
    window.location.href = '/login';
  },

  // Get current user from localStorage (no API call)
  getUser: () => {
    const user = localStorage.getItem('flowra_user');
    return user ? JSON.parse(user) : null;
  },

  isLoggedIn: () => !!localStorage.getItem('flowra_token'),
};

// ─── Automations ───────────────────────────────────────────────
export const automations = {
  list: () =>
    request('/automations'),

  get: (id) =>
    request(`/automations/${id}`),

  create: (data) =>
    request('/automations', { method: 'POST', body: data }),

  update: (id, data) =>
    request(`/automations/${id}`, { method: 'PATCH', body: data }),

  delete: (id) =>
    request(`/automations/${id}`, { method: 'DELETE' }),

  run: (id) =>
    request(`/automations/${id}/run`, { method: 'POST' }),

  toggle: (id, isActive) =>
    request(`/automations/${id}`, { method: 'PATCH', body: { is_active: isActive } }),
};

// ─── Logs ──────────────────────────────────────────────────────
export const logs = {
  list: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return request(`/logs${query ? '?' + query : ''}`);
  },

  stats: () => request('/logs/stats'),

  get: (id) => request(`/logs/${id}`),
};
