// hooks/useAutomations.js
// Paste this into your src/hooks/ folder

import { useState, useEffect, useCallback } from 'react';
import { automations as api } from '../api';

export function useAutomations() {
  const [data, setData]       = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  // Fetch all automations
  const fetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.list();
      setData(result);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  // Create a new automation
  const create = async (formData) => {
    const newItem = await api.create(formData);
    setData(prev => [newItem, ...prev]);
    return newItem;
  };

  // Toggle active/inactive
  const toggle = async (id, isActive) => {
    await api.toggle(id, isActive);
    setData(prev => prev.map(a => a.id === id ? { ...a, is_active: isActive } : a));
  };

  // Manually run an automation
  const run = async (id) => {
    await api.run(id);
    // Optimistically update last_run_at
    setData(prev => prev.map(a =>
      a.id === id ? { ...a, last_run_at: new Date().toISOString() } : a
    ));
  };

  // Delete an automation
  const remove = async (id) => {
    await api.delete(id);
    setData(prev => prev.filter(a => a.id !== id));
  };

  return { data, loading, error, refresh: fetch, create, toggle, run, remove };
}


// ─── useLogs hook ─────────────────────────────────────────────
import { logs as logsAPI } from '../api';

export function useLogs(params = {}) {
  const [data, setData]       = useState([]);
  const [stats, setStats]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [logsResult, statsResult] = await Promise.all([
          logsAPI.list(params),
          logsAPI.stats(),
        ]);
        setData(logsResult);
        setStats(statsResult);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  return { data, stats, loading, error };
}
