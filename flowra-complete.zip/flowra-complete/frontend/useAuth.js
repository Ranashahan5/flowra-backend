// hooks/useAuth.js
// Paste this into your src/hooks/ folder

import { useState, useEffect, createContext, useContext } from 'react';
import { auth as authAPI } from '../api';

const AuthContext = createContext(null);

// Wrap your app with this provider in main.jsx / App.jsx
export function AuthProvider({ children }) {
  const [user, setUser] = useState(authAPI.getUser());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const login = async (email, password) => {
    setLoading(true);
    setError(null);
    try {
      const data = await authAPI.login(email, password);
      authAPI.saveSession(data);
      setUser(data.user);
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const register = async (email, password) => {
    setLoading(true);
    setError(null);
    try {
      const data = await authAPI.register(email, password);
      authAPI.saveSession(data);
      setUser(data.user);
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    authAPI.logout();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, error, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Use this hook in any component
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside <AuthProvider>');
  return context;
}

// Redirect to /login if not authenticated
export function useRequireAuth() {
  const { user } = useAuth();
  useEffect(() => {
    if (!user) window.location.href = '/login';
  }, [user]);
  return user;
}
