// ─────────────────────────────────────────────────────────────
// HOW TO WIRE YOUR AI-GENERATED UI TO THE BACKEND
// Copy the relevant snippet into your component
// ─────────────────────────────────────────────────────────────


// ── 1. WRAP YOUR APP (main.jsx or App.jsx) ───────────────────
import { AuthProvider } from './hooks/useAuth';

function App() {
  return (
    <AuthProvider>
      {/* your router / pages here */}
    </AuthProvider>
  );
}


// ── 2. LOGIN PAGE ────────────────────────────────────────────
import { useAuth } from './hooks/useAuth';
import { useNavigate } from 'react-router-dom';

function LoginPage() {
  const { login, loading, error } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const email    = e.target.email.value;
    const password = e.target.password.value;
    try {
      await login(email, password);
      navigate('/dashboard');       // redirect on success
    } catch (_) {}                  // error shown from `error` state
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="email"    type="email"    placeholder="Email" />
      <input name="password" type="password" placeholder="Password" />
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <button type="submit" disabled={loading}>
        {loading ? 'Logging in...' : 'Login'}
      </button>
    </form>
  );
}


// ── 3. DASHBOARD STATS ───────────────────────────────────────
import { useLogs } from './hooks/useAutomations';

function DashboardStats() {
  const { stats, loading } = useLogs();

  if (loading) return <p>Loading stats...</p>;

  return (
    <div>
      <p>Runs today: {stats.runs_today}</p>
      <p>Total success: {stats.total_success}</p>
      <p>Total failed: {stats.total_failed}</p>
      <p>Avg duration: {Math.round(stats.avg_duration_ms)}ms</p>
    </div>
  );
}


// ── 4. AUTOMATIONS LIST ──────────────────────────────────────
import { useAutomations } from './hooks/useAutomations';

function AutomationsList() {
  const { data, loading, error, toggle, run, remove } = useAutomations();

  if (loading) return <p>Loading...</p>;
  if (error)   return <p>Error: {error}</p>;

  return (
    <ul>
      {data.map(automation => (
        <li key={automation.id}>
          <span>{automation.name}</span>
          <span>{automation.last_run_at ? new Date(automation.last_run_at).toLocaleString() : 'Never'}</span>

          {/* Toggle on/off */}
          <input
            type="checkbox"
            checked={automation.is_active}
            onChange={(e) => toggle(automation.id, e.target.checked)}
          />

          {/* Run now */}
          <button onClick={() => run(automation.id)}>▶ Run</button>

          {/* Delete */}
          <button onClick={() => remove(automation.id)}>🗑 Delete</button>
        </li>
      ))}
    </ul>
  );
}


// ── 5. CREATE AUTOMATION FORM ────────────────────────────────
import { useAutomations } from './hooks/useAutomations';

function CreateAutomationForm() {
  const { create } = useAutomations();

  const handleSubmit = async (e) => {
    e.preventDefault();
    await create({
      name:           e.target.name.value,
      start_url:      e.target.start_url.value,
      trigger_type:   e.target.trigger_type.value,
      trigger_config: e.target.trigger_type.value === 'schedule'
                        ? { cron: e.target.cron.value }
                        : {},
      steps: [],   // Steps will be filled in by Chrome Extension later
    });
    e.target.reset();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name"      placeholder="Automation name" required />
      <input name="start_url" placeholder="https://example.com" required />

      <select name="trigger_type">
        <option value="manual">Manual</option>
        <option value="schedule">Schedule (cron)</option>
      </select>

      {/* Show cron input only when schedule is selected */}
      <input name="cron" placeholder="0 9 * * 1-5  (weekdays 9am)" />

      <button type="submit">Create</button>
    </form>
  );
}


// ── 6. LOGS TABLE ────────────────────────────────────────────
import { useLogs } from './hooks/useAutomations';

function LogsTable() {
  const { data, loading } = useLogs();

  if (loading) return <p>Loading logs...</p>;

  return (
    <table>
      <thead>
        <tr>
          <th>Automation</th>
          <th>Status</th>
          <th>Duration</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody>
        {data.map(log => (
          <tr key={log.id}>
            <td>{log.automation_name}</td>
            <td style={{ color: log.status === 'success' ? 'green' : log.status === 'failed' ? 'red' : 'orange' }}>
              {log.status}
            </td>
            <td>{log.duration_ms ? `${log.duration_ms}ms` : '—'}</td>
            <td>{new Date(log.started_at).toLocaleString()}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
