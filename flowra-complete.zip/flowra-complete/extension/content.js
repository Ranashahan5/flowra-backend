// content.js — Injected into every webpage
// Listens for user actions and sends them to background.js

let isRecording = false;
let steps = [];

// ─── Listen for messages from popup/background ────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'START_RECORDING') {
    startRecording();
    sendResponse({ status: 'recording' });
  }

  if (message.type === 'STOP_RECORDING') {
    const recorded = stopRecording();
    sendResponse({ steps: recorded });
  }

  if (message.type === 'GET_STATUS') {
    sendResponse({ isRecording, stepCount: steps.length });
  }
});

// ─── Start recording ─────────────────────────────────────────
function startRecording() {
  isRecording = true;
  steps = [];

  // Record the current page URL as first step
  steps.push({ type: 'navigate', url: window.location.href });

  // Attach all event listeners
  document.addEventListener('click',   handleClick,   true);
  document.addEventListener('input',   handleInput,   true);
  document.addEventListener('change',  handleChange,  true);
  document.addEventListener('keydown', handleKeydown, true);

  // Show recording indicator on page
  showRecordingBadge();

  console.log('[Flowra] 🔴 Recording started');
}

// ─── Stop recording ──────────────────────────────────────────
function stopRecording() {
  isRecording = false;

  document.removeEventListener('click',   handleClick,   true);
  document.removeEventListener('input',   handleInput,   true);
  document.removeEventListener('change',  handleChange,  true);
  document.removeEventListener('keydown', handleKeydown, true);

  removeRecordingBadge();

  console.log(`[Flowra] ⏹ Recording stopped — ${steps.length} steps`);
  return steps;
}

// ─── Event Handlers ──────────────────────────────────────────

function handleClick(event) {
  if (!isRecording) return;

  const el = event.target;

  // Skip clicks on our own recording badge
  if (el.id === 'flowra-badge') return;

  const selector = getSelector(el);
  if (!selector) return;

  // Don't double-record if we already recorded an input for this element
  const lastStep = steps[steps.length - 1];
  if (lastStep?.selector === selector && lastStep?.type === 'fill') return;

  steps.push({ type: 'click', selector });
  updateBadgeCount();
}

// Track input values with a small delay (capture final value)
const inputTimers = new Map();

function handleInput(event) {
  if (!isRecording) return;

  const el = event.target;
  if (!['INPUT', 'TEXTAREA'].includes(el.tagName)) return;
  if (['password', 'hidden'].includes(el.type)) return; // Never record passwords

  const selector = getSelector(el);
  if (!selector) return;

  // Debounce: wait 600ms after last keystroke before recording
  clearTimeout(inputTimers.get(selector));
  inputTimers.set(selector, setTimeout(() => {
    // Replace previous fill step for same field, or add new
    const existingIdx = steps.findLastIndex(s => s.selector === selector && s.type === 'fill');
    const step = { type: 'fill', selector, value: el.value };

    if (existingIdx !== -1) {
      steps[existingIdx] = step; // Update in place
    } else {
      steps.push(step);
    }
    updateBadgeCount();
  }, 600));
}

function handleChange(event) {
  if (!isRecording) return;

  const el = event.target;
  if (el.tagName !== 'SELECT') return;

  const selector = getSelector(el);
  if (!selector) return;

  steps.push({ type: 'select', selector, value: el.value });
  updateBadgeCount();
}

function handleKeydown(event) {
  if (!isRecording) return;

  // Only record meaningful key presses
  const recordedKeys = ['Enter', 'Tab', 'Escape'];
  if (!recordedKeys.includes(event.key)) return;

  // Don't record Tab inside forms (too noisy)
  if (event.key === 'Tab') return;

  steps.push({ type: 'keyPress', key: event.key });
  updateBadgeCount();
}

// ─── Smart CSS Selector Generator ────────────────────────────
// Tries to find the most stable, unique selector for an element

function getSelector(el) {
  if (!el || el === document.body) return null;

  // 1. Prefer ID (most stable)
  if (el.id && !el.id.match(/^\d/)) {
    return `#${CSS.escape(el.id)}`;
  }

  // 2. Use data-testid or aria-label (very stable in apps)
  if (el.dataset.testid) return `[data-testid="${el.dataset.testid}"]`;
  if (el.getAttribute('aria-label')) return `[aria-label="${el.getAttribute('aria-label')}"]`;
  if (el.name) return `${el.tagName.toLowerCase()}[name="${el.name}"]`;

  // 3. Build path from parent
  return buildSelectorPath(el);
}

function buildSelectorPath(el) {
  const parts = [];
  let current = el;

  while (current && current !== document.body) {
    let part = current.tagName.toLowerCase();

    if (current.id) {
      parts.unshift(`#${CSS.escape(current.id)}`);
      break; // ID is unique, stop here
    }

    // Add nth-child to disambiguate siblings
    const siblings = Array.from(current.parentNode?.children || [])
      .filter(s => s.tagName === current.tagName);

    if (siblings.length > 1) {
      const index = siblings.indexOf(current) + 1;
      part += `:nth-of-type(${index})`;
    }

    parts.unshift(part);
    current = current.parentNode;

    if (parts.length > 4) break; // Don't go too deep
  }

  return parts.join(' > ');
}

// ─── Recording Badge UI ──────────────────────────────────────
// Small red dot shown on page while recording

function showRecordingBadge() {
  const badge = document.createElement('div');
  badge.id = 'flowra-badge';
  badge.innerHTML = `
    <span style="
      display:inline-block;
      width:10px; height:10px;
      background:red;
      border-radius:50%;
      margin-right:6px;
      animation: pulse 1s infinite;
    "></span>
    Recording... <span id="flowra-count">1</span> steps
  `;
  badge.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #1a1a1a;
    color: white;
    padding: 8px 14px;
    border-radius: 20px;
    font-size: 13px;
    font-family: sans-serif;
    z-index: 999999;
    box-shadow: 0 4px 12px rgba(0,0,0,0.4);
    display: flex;
    align-items: center;
    pointer-events: none;
  `;

  // Add pulse animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.3; }
    }
  `;
  document.head.appendChild(style);
  document.body.appendChild(badge);
}

function updateBadgeCount() {
  const counter = document.getElementById('flowra-count');
  if (counter) counter.textContent = steps.length;
}

function removeRecordingBadge() {
  document.getElementById('flowra-badge')?.remove();
}
