// background.js — Service worker
// Manages recording state across tabs and sends data to Flowra backend

const API_URL = 'http://localhost:3000/api'; // Change to production URL when deployed

let recordingTabId = null;
let recordingState = {
  isRecording: false,
  automationName: '',
  startUrl: '',
  steps: [],
};

// ─── Message handler ─────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // Popup starts recording
  if (message.type === 'POPUP_START_RECORDING') {
    startRecording(message.name, message.tabId);
    sendResponse({ ok: true });
  }

  // Popup stops recording + saves automation
  if (message.type === 'POPUP_STOP_AND_SAVE') {
    stopAndSave(message.triggerType, message.cron, sendResponse);
    return true; // Keep channel open for async response
  }

  // Popup checks current state
  if (message.type === 'POPUP_GET_STATE') {
    sendResponse(recordingState);
  }

  // Content script finished stopping
  if (message.type === 'CONTENT_STOPPED') {
    recordingState.steps = message.steps;
  }
});

// ─── Start recording ─────────────────────────────────────────
async function startRecording(name, tabId) {
  recordingTabId = tabId;

  // Get current tab URL as start URL
  const tab = await chrome.tabs.get(tabId);

  recordingState = {
    isRecording: true,
    automationName: name,
    startUrl: tab.url,
    steps: [],
  };

  // Tell content script to start listening
  await chrome.tabs.sendMessage(tabId, { type: 'START_RECORDING' });

  // Update extension icon to red
  chrome.action.setIcon({
    tabId,
    path: { 16: 'icons/icon_recording16.png' }
  });

  console.log('[Flowra BG] Recording started on tab:', tabId);
}

// ─── Stop recording and save to backend ──────────────────────
async function stopAndSave(triggerType, cron, sendResponse) {
  if (!recordingTabId) {
    sendResponse({ ok: false, error: 'No active recording' });
    return;
  }

  try {
    // Get steps from content script
    const response = await chrome.tabs.sendMessage(recordingTabId, {
      type: 'STOP_RECORDING'
    });

    const steps = response.steps || [];

    // Reset icon
    chrome.action.setIcon({ path: { 16: 'icons/icon16.png' } });

    // Get auth token from storage
    const { token } = await chrome.storage.local.get('token');

    if (!token) {
      sendResponse({ ok: false, error: 'Not logged in. Please log in on Flowra first.' });
      return;
    }

    // Save to backend
    const saveResponse = await fetch(`${API_URL}/automations`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({
        name: recordingState.automationName,
        start_url: recordingState.startUrl,
        steps,
        trigger_type: triggerType || 'manual',
        trigger_config: triggerType === 'schedule' ? { cron } : {},
      }),
    });

    const data = await saveResponse.json();

    if (!saveResponse.ok) {
      sendResponse({ ok: false, error: data.error });
      return;
    }

    // Reset state
    recordingState = { isRecording: false, automationName: '', startUrl: '', steps: [] };
    recordingTabId = null;

    sendResponse({ ok: true, automation: data, stepCount: steps.length });

  } catch (err) {
    console.error('[Flowra BG] Save error:', err);
    sendResponse({ ok: false, error: err.message });
  }
}

// ─── Sync token from web app ──────────────────────────────────
// When user logs in on Flowra website, sync their token to extension
chrome.cookies.onChanged?.addListener((change) => {
  if (change.cookie.name === 'flowra_token') {
    chrome.storage.local.set({ token: change.cookie.value });
  }
});
