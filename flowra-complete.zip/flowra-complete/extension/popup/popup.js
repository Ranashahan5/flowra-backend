// popup.js — Controls the extension popup UI

const API_URL = 'http://localhost:3000/api';

// ─── DOM refs ────────────────────────────────────────────────
const loginScreen      = document.getElementById('login-screen');
const mainScreen       = document.getElementById('main-screen');
const userBar          = document.getElementById('user-bar');
const userEmailEl      = document.getElementById('user-email');

const loginBtn         = document.getElementById('login-btn');
const loginEmailInput  = document.getElementById('login-email');
const loginPassInput   = document.getElementById('login-password');
const loginError       = document.getElementById('login-error');

const recordBtn        = document.getElementById('record-btn');
const stopBtn          = document.getElementById('stop-btn');
const cancelBtn        = document.getElementById('cancel-btn');
const recordForm       = document.getElementById('record-form');
const recordingCtrls   = document.getElementById('recording-controls');

const autoNameInput    = document.getElementById('auto-name');
const triggerSelect    = document.getElementById('trigger-type');
const cronRow          = document.getElementById('cron-row');
const cronInput        = document.getElementById('cron-input');

const statusDot        = document.getElementById('status-dot');
const statusTitle      = document.getElementById('status-title');
const statusSub        = document.getElementById('status-sub');
const stepCountEl      = document.getElementById('step-count');

const mainError        = document.getElementById('main-error');
const mainSuccess      = document.getElementById('main-success');
const logoutBtn        = document.getElementById('logout-btn');

// ─── Init ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  const { token, userEmail } = await chrome.storage.local.get(['token', 'userEmail']);

  if (token) {
    showMainScreen(userEmail);
    checkIfRecording();
  } else {
    showLoginScreen();
  }
});

// ─── Login ───────────────────────────────────────────────────
loginBtn.addEventListener('click', async () => {
  const email    = loginEmailInput.value.trim();
  const password = loginPassInput.value;

  if (!email || !password) {
    showError(loginError, 'Please fill in both fields');
    return;
  }

  loginBtn.disabled = true;
  loginBtn.textContent = 'Logging in...';
  hideError(loginError);

  try {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();

    if (!res.ok) {
      showError(loginError, data.error || 'Login failed');
      return;
    }

    // Save token
    await chrome.storage.local.set({ token: data.token, userEmail: email });
    showMainScreen(email);

  } catch (err) {
    showError(loginError, 'Could not connect to Flowra server');
  } finally {
    loginBtn.disabled = false;
    loginBtn.textContent = 'Log In';
  }
});

// Allow Enter key to submit login
loginPassInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') loginBtn.click();
});

// ─── Logout ──────────────────────────────────────────────────
logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.remove(['token', 'userEmail']);
  showLoginScreen();
});

// ─── Show/hide cron field ─────────────────────────────────────
triggerSelect.addEventListener('change', () => {
  cronRow.style.display = triggerSelect.value === 'schedule' ? 'block' : 'none';
});

// ─── Start recording ─────────────────────────────────────────
recordBtn.addEventListener('click', async () => {
  const name = autoNameInput.value.trim();
  if (!name) {
    showError(mainError, 'Please enter an automation name');
    return;
  }

  hideError(mainError);

  // Get the active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Tell background to start recording
  await chrome.runtime.sendMessage({
    type: 'POPUP_START_RECORDING',
    name,
    tabId: tab.id,
  });

  setRecordingUI(true);

  // Poll step count every second
  startStepCountPoll(tab.id);
});

// ─── Stop & save ─────────────────────────────────────────────
stopBtn.addEventListener('click', async () => {
  stopBtn.disabled = true;
  stopBtn.textContent = 'Saving...';
  clearStepCountPoll();

  const triggerType = triggerSelect.value;
  const cron = cronInput.value.trim();

  if (triggerType === 'schedule' && !cron) {
    showError(mainError, 'Please enter a cron expression');
    stopBtn.disabled = false;
    stopBtn.textContent = '⏹ Stop & Save';
    return;
  }

  const response = await chrome.runtime.sendMessage({
    type: 'POPUP_STOP_AND_SAVE',
    triggerType,
    cron,
  });

  stopBtn.disabled = false;
  stopBtn.textContent = '⏹ Stop & Save';
  setRecordingUI(false);

  if (response.ok) {
    mainSuccess.style.display = 'block';
    mainSuccess.textContent = `✅ Saved "${response.automation.name}" — ${response.stepCount} steps recorded!`;
    autoNameInput.value = '';
    setTimeout(() => { mainSuccess.style.display = 'none'; }, 4000);
  } else {
    showError(mainError, response.error || 'Failed to save automation');
  }
});

// ─── Cancel recording ─────────────────────────────────────────
cancelBtn.addEventListener('click', async () => {
  clearStepCountPoll();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.tabs.sendMessage(tab.id, { type: 'STOP_RECORDING' });
  setRecordingUI(false);
  statusTitle.textContent = 'Recording cancelled';
  setTimeout(() => { statusTitle.textContent = 'Ready to record'; }, 2000);
});

// ─── Check if already recording (popup reopened mid-recording)
async function checkIfRecording() {
  const state = await chrome.runtime.sendMessage({ type: 'POPUP_GET_STATE' });
  if (state?.isRecording) {
    setRecordingUI(true);
    autoNameInput.value = state.automationName;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    startStepCountPoll(tab.id);
  }
}

// ─── Poll content script for live step count ──────────────────
let pollInterval = null;

function startStepCountPoll(tabId) {
  pollInterval = setInterval(async () => {
    try {
      const res = await chrome.tabs.sendMessage(tabId, { type: 'GET_STATUS' });
      if (res) stepCountEl.textContent = res.stepCount;
    } catch (_) {}
  }, 1000);
}

function clearStepCountPoll() {
  clearInterval(pollInterval);
  pollInterval = null;
}

// ─── UI helpers ───────────────────────────────────────────────
function setRecordingUI(recording) {
  recordForm.style.display     = recording ? 'none' : 'block';
  recordingCtrls.style.display = recording ? 'block' : 'none';
  statusDot.className = 'status-dot' + (recording ? ' recording' : '');
  statusTitle.textContent = recording ? 'Recording...' : 'Ready to record';
  statusSub.textContent   = recording
    ? 'Perform your task in the browser tab'
    : 'Set a name and press Record';
}

function showMainScreen(email) {
  loginScreen.style.display = 'none';
  mainScreen.style.display  = 'block';
  userBar.style.display     = 'flex';
  userEmailEl.textContent   = email || '';
}

function showLoginScreen() {
  loginScreen.style.display = 'block';
  mainScreen.style.display  = 'none';
  userBar.style.display     = 'none';
}

function showError(el, msg) {
  el.textContent   = msg;
  el.style.display = 'block';
}

function hideError(el) {
  el.style.display = 'none';
}
