# Flowra Chrome Extension

Records browser actions and saves them as automations on your Flowra backend.

---

## How to Install (Developer Mode)

1. Open Chrome → go to `chrome://extensions`
2. Toggle **Developer mode** ON (top right)
3. Click **Load unpacked**
4. Select this `flowra-extension` folder
5. The Flowra icon appears in your toolbar ✅

---

## How It Works

1. Click the Flowra icon in Chrome
2. Log in with your Flowra account
3. Type a name for your automation
4. Click **Start Recording** 🔴
5. Perform the task you want to automate (click, fill forms, navigate)
6. Click **Stop & Save** ⏹
7. Automation is saved to your backend and visible in the dashboard

---

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | Extension config |
| `content.js` | Injected into pages — records clicks, typing, form fills |
| `background.js` | Service worker — manages state and API calls |
| `popup/popup.html` | The popup UI |
| `popup/popup.js` | Popup logic |

---

## Before Publishing to Production

1. Change `API_URL` in both `background.js` and `popup/popup.js` to your Render URL
2. Add real icon PNG files in the `icons/` folder (16x16, 48x48, 128x128)
3. Submit to Chrome Web Store ($5 one-time developer fee)

---

## Step Types Recorded

| Action | Recorded as |
|--------|------------|
| Click a button/link | `click` |
| Type in an input | `fill` |
| Choose a dropdown | `select` |
| Press Enter | `keyPress` |
| Page navigation | `navigate` |
